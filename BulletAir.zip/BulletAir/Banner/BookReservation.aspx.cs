﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data.SqlClient;

namespace Banner
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string season = CheckSeason();
            HttpCookie seasoncookie = new HttpCookie("Season");
            seasoncookie.Value = season;
            seasoncookie.Expires = DateTime.Now.AddDays(1);
            Response.Cookies.Add(seasoncookie);

            lblPassengerName.Visible = false;
            txtPassengerName.Visible = false;
            btnBookReservation.Visible = false;
            gvReservations2.Visible = false;
        }

        protected void btnCheckAvailability_Click(object sender, EventArgs e)
        {
            string user = HttpContext.Current.User.Identity.Name;
            string FlightNo = ddlFlightNumber.SelectedValue;
            string FlightDate = ddlFlightDate.SelectedValue;
            string SeatType = ddlSeatType.SelectedValue;
            string ClassType = ddlClassType.SelectedValue;

            ReservationService BookReservation = new ReservationService();
            int avSeatNo = BookReservation.Reserve(FlightNo, FlightDate, SeatType, ClassType);
            if (avSeatNo == 0)
            {
                ltlBookReservation.Text = "No seats available.";
            }
            else
            {
                //gvReservations2.DataSource = Reservations2DS;
                //gvReservations.DataBind();
                ltlBookReservation.Text = "Seat Number: " + avSeatNo;

                HttpCookie seatnocookie = new HttpCookie("SeatNo");
                seatnocookie.Value = avSeatNo.ToString();
                seatnocookie.Expires = DateTime.Now.AddDays(1);
                Response.Cookies.Add(seatnocookie);

                lblPassengerName.Visible = true;
                txtPassengerName.Visible = true;
                btnBookReservation.Visible = true;
                gvReservations2.Visible = true;
            }

        }
        protected void btnBookReservation_Click(object sender, EventArgs e)
        {
            string season = Request.Cookies["Season"].Value;

            string user = HttpContext.Current.User.Identity.Name;
            string FlightNo = ddlFlightNumber.SelectedValue;
            string FlightDate = ddlFlightDate.SelectedValue;
            string SeatType = ddlSeatType.SelectedValue;
            string ClassType = ddlClassType.SelectedValue;
            string SeatNo = Request.Cookies["SeatNo"].Value;
            string PassengerName = txtPassengerName.Text;
            int Discount = 10;

            //gvReservations2.SelectedIndex = 1;
            GridViewRow seatprice = gvReservations2.Rows[0];

           int InitialPrice = Convert.ToInt32(seatprice.Cells[4].Text);
           float FinalPrice = (1-((float)Discount / 100)) * ((float)InitialPrice);

            

            //FlightFare (FlightNo, SeatType, Season, Price)


            string strInsert = "INSERT INTO Reservation "
                                       + " VALUES ('" + FlightNo + "', '"
                                       + FlightDate + "', '"
                                       + SeatNo + "', '"
                                       + ClassType + "', '"
                                       + SeatType + "', '"
                                       + user + "', '"
                                       + PassengerName + "', "
                                       + Discount + ", "
                                       + FinalPrice + ", "
                                       + InitialPrice
                                       + " )";
                SqlConnection conn2 = new SqlConnection();
                conn2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|reservation.mdf;Integrated Security=True;User Instance=True";

                SqlCommand cmdInsert = new SqlCommand(strInsert, conn2);

                //SqlDataReader cmdReader;

                conn2.Open();
                try
                {

                    cmdInsert.ExecuteNonQuery();
                    //cmdReader.Read();
                    //string userid = cmdReader.GetValue(0).ToString();
                    conn2.Close();
                    //lblNoteAdd.Visible = true;
                    ltlBookReservation2.Text = "Success! Reservation has been made.";

                    //lblNoteAdd0.Text = "Success! " + MajorCode + " " + CourseNo + " has been added.";
                    //gvViewSched.UpdateMethod();
                }
                catch (SqlException ex)
                {
                    if (ex.Number == 2627)
                    {
                        ltlBookReservation2.Text = "This reservation has already been made.";
                    }
                }
            
        }

        string CheckSeason()
        {
            DateTime now = DateTime.Now;

            if ((now.Month < 9 && now.Month >= 6) || (now.Month < 2 && now.Month >= 12))
            {
                return "High";
            }
            if ((now.Month < 11 && now.Month >= 9) || (now.Month < 5 && now.Month >= 2))
            {
                return "Low";
            }
            else
            {
                return "Medium";
            }
        }
    }
}