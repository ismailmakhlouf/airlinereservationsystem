﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;

namespace Banner
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string user = HttpContext.Current.User.Identity.Name;
            HttpCookie usercookie = new HttpCookie("UserName");
            usercookie.Value = user;
            usercookie.Expires = DateTime.Now.AddDays(1);
            Response.Cookies.Add(usercookie);
        }

        protected void btnOfferings_Click(object sender, EventArgs e)
        {
            GridViewRow reservation = gvUserReservations.SelectedRow;

            string FlightNo = reservation.Cells[1].Text;
            string FlightDate = reservation.Cells[2].Text;
            string SeatNo = reservation.Cells[3].Text;
            

            ReservationService BookReservation = new ReservationService();
            bool success = BookReservation.Cancel(FlightNo, FlightDate, SeatNo);
            if (success)
            {
                ltlCancelReservation.Text = "Success. Reservation has been canceled";
            }
            else
            {
                ltlCancelReservation.Text = "Error. Reservation has not been canceled";
            }
        }
    }
}