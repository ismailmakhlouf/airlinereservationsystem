﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Banner
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //string user = HttpContext.Current.User.Identity.Name;
            //HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            //FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            

            if (!Request.IsAuthenticated)
            {
                this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
                
            }
            else
            {
                //Login1.DestinationPageUrl = "~/Secure/" + Roles.GetRolesForUser()[0] + "/" + Roles.GetRolesForUser()[0] + ".aspx";
                //Response.Redirect ("~/Secure/" + Roles.GetRolesForUser()[0] + "/" + Roles.GetRolesForUser()[0] + ".aspx");
            }
        }

        protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
        {
            //FormsAuthentication.SignOut();
            if (Membership.ValidateUser(Login1.UserName, Login1.Password))
            {
                FormsAuthentication.SetAuthCookie(Login1.UserName, true);

                
                //Login1.DestinationPageUrl = "~/Secure/" + Roles.GetRolesForUser()[0] + "/" + Roles.GetRolesForUser()[0] + ".aspx";
                string deststring = "~/Secure/" + Roles.GetRolesForUser(Login1.UserName)[0] + "/" + Roles.GetRolesForUser(Login1.UserName)[0] + ".aspx";
                Response.Redirect(deststring);
                //Response.Redirect("~/secure/admin/admin.aspx");
            }
            
            
        }

        protected void PasswordRecovery1_SendingMail(object sender, MailMessageEventArgs e)
        {
            ltlMail.Text = "Check your email.";
        }
    }
}

