﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

namespace Banner
{
    /// <summary>
    /// Summary description for ReservationService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    //[WebService(Namespace = "http://localhost/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class ReservationService : System.Web.Services.WebService
    {

        [WebMethod]
        public int Reserve(string FlightNo, string FlightDate, string SeatType, string ClassType)
        {
            string strSelect = "SELECT SeatNo "
                               + "FROM SeatAvailability "
                               + "WHERE (Fdate = '" + FlightDate + "') AND (ClassType = '" + ClassType + "') AND (FlightNo = '" + FlightNo + "')  AND (SeatType = '" + SeatType + "') AND (Status = 0)";

            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|CentralDB.mdf;Integrated Security=True;User Instance=True";
            
            SqlDataAdapter daReserve = new SqlDataAdapter(strSelect, conn);
            DataSet dsReserve = new DataSet("Reservation");

            daReserve.FillSchema(dsReserve, SchemaType.Source, "Reservation");
            daReserve.Fill(dsReserve, "Reservation");
            DataTable dtReserve = dsReserve.Tables["Reservation"];

            DataTableReader drReserve = dsReserve.CreateDataReader();
            if (drReserve.HasRows)
            {
                return (int)dtReserve.Rows[0][0];
            }
            else
            {
                return 0;
            }
        }

        [WebMethod]
        public bool Cancel(string FlightNo, string FlightDate, string SeatNo)
        {
           
            string strUpdate = "UPDATE SeatAvailability "
                                       + "SET Status = 0 "
                                       + "WHERE (Fdate = '" + FlightDate + "') AND (FlightNo = '" + FlightNo + "')  AND (SeatNo = " + SeatNo + ")";
        
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|CentralDB.mdf;Integrated Security=True;User Instance=True";

            return true;
        }
    }
}
