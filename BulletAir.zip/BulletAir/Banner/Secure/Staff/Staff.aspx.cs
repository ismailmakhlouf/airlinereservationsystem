﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Banner
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            TabContainer1.AutoPostBack = true;
            TabContainer1.Visible = true;

            gvOfferings.Visible = true;

            if (!IsPostBack & !IsCallback)
            {
                //This makes performing paging and sorting uses AJAX.
                gvOfferings.EnableSortingAndPagingCallbacks = true;
                //Small number so that I can see many oages out of
                // 9 rows only (Yhe total Rows Count of Northwind's Employees DataTable).
                //Also selected it in a way that last Page Rows Count will be
                // different than other pages.
                //GridView1.PageSize = 2;
                //if (!IsPostBack)   //Just to prove the AJAX thing.
                //{
                //    PostBackStatus.Text = "Not PostBack";
                //}
                //else   //Never happens, as I don't require a PostBack.
                //{
                //    PostBackStatus.Text = "Page Is PostBack";
                //}

                string user = HttpContext.Current.User.Identity.Name;
                string strSelect = "SELECT StudentId, FirstName, LastName FROM Student WHERE (UserName = '" + user + "')";


                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|UniversityServices.mdf;Integrated Security=True;User Instance=True";


                SqlCommand cmdSelect = new SqlCommand(strSelect, conn);

                SqlDataReader cmdReader;

                conn.Open();
                cmdReader = cmdSelect.ExecuteReader();
                cmdReader.Read();
                string userid = cmdReader.GetValue(0).ToString();
                string fname = cmdReader.GetValue(1).ToString();
                string lname = cmdReader.GetValue(2).ToString();

                conn.Close();

                HttpCookie usercookie = new HttpCookie("UserId");
                usercookie.Value = userid;
                usercookie.Expires = DateTime.Now.AddDays(1);
                Response.Cookies.Add(usercookie);

                HttpCookie namecookie = new HttpCookie("UserName");
                namecookie.Value = fname + " " + lname;
                namecookie.Expires = DateTime.Now.AddDays(1);
                Response.Cookies.Add(namecookie);
            }



            //GridViewRow offer = gvOfferings.SelectedRow;
            //string s = BrowseOfferingsDS.SelectParameters.ToString();



        }

        protected void SelectedIndex_OnChanged(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            string strSelect = "SELECT Semester, Year, AddStart, AddEnd, DropStart, DropEnd, PostStart, PostEnd "
                                  + "FROM Deadlines "
                                  + "WHERE (Semester = '" + ddlSemester3.Text + "') "
                                  + "AND (Year = " + ddlYear3.Text + ") ";

            SqlDataReader cmdReaderdates;

            string connstring = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|UniversityServices.mdf;Integrated Security=True;User Instance=True";
            cmdReaderdates = selectcmd(strSelect, connstring);
            cmdReaderdates.Read();

            DateTime PostStart = (DateTime)cmdReaderdates.GetValue(6);
            DateTime PostEnd = (DateTime)cmdReaderdates.GetValue(7);
            DateTime now = DateTime.Now;

            if ((now >= PostStart) && (now <= PostEnd))
            {
                GridViewRow grade = gvPostGrades.SelectedRow;

                if (grade != null)
                {
                    string FullName = grade.Cells[1].Text;
                    string MajorCode = grade.Cells[2].Text;
                    string CourseNo = grade.Cells[3].Text;
                    string SectionNo = grade.Cells[4].Text;
                    string Semester = grade.Cells[5].Text;
                    string Year = grade.Cells[6].Text;
                    string UWMR = grade.Cells[7].Text;
                    string StartTime = grade.Cells[8].Text;
                    string CurrentGrade = grade.Cells[9].Text;
                    string FinalGrade = ddlGrade.SelectedValue;
                    if (FinalGrade == "Remove Current Grade")
                    {
                        FinalGrade = "";
                    }


                    strSelect = "SELECT StudentId FROM Student WHERE (FirstName + ' ' + Lastname) = '" + FullName + "'";


                    SqlConnection conn = new SqlConnection();
                    conn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|UniversityServices.mdf;Integrated Security=True;User Instance=True";


                    SqlCommand cmdSelect = new SqlCommand(strSelect, conn);

                    SqlDataReader cmdReader;

                    conn.Open();
                    cmdReader = cmdSelect.ExecuteReader();
                    cmdReader.Read();
                    string studentid = cmdReader.GetValue(0).ToString();
                    conn.Close();


                    string strUpdate = "UPDATE Transcript "
                                        + "SET Grade = '" + FinalGrade + "' "
                                        + "WHERE (StudentId = '" + studentid + "') "
                                        + "AND (MajorCode = '" + MajorCode + "') "
                                        + "AND (CourseNo = '" + CourseNo + "') "
                                        + "AND (SectionNo = " + SectionNo + ") "
                                        + "AND (Semester = '" + Semester + "') "
                                        + "AND (Year = " + Year + ")";


                    SqlConnection conn2 = new SqlConnection();
                    conn2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|UniversityServices.mdf;Integrated Security=True;User Instance=True";

                    SqlCommand cmdInsert = new SqlCommand(strUpdate, conn2);

                    //SqlDataReader cmdReader;

                    conn2.Open();
                    try
                    {

                        cmdInsert.ExecuteNonQuery();
                        //cmdReader.Read();
                        //string userid = cmdReader.GetValue(0).ToString();
                        conn2.Close();
                        ltlGrades.Visible = true;
                        if (FinalGrade != "")
                        {
                            ltlGrades.Text = "Success! " + FullName + " has recieved a grade of " + FinalGrade + " for " + MajorCode + " " + CourseNo;
                        }
                        else
                        {
                            ltlGrades.Text = "Success! " + FullName + " has no grade for " + MajorCode + " " + CourseNo;
                        }
                        //lblNoteAdd0.Text = "Success! " + MajorCode + " " + CourseNo + " has been added.";
                        //gvViewSched.UpdateMethod();
                    }
                    catch (SqlException ex)
                    {
                        if (ex.Number == 2627)
                        {
                            ltlGrades.Text = "This course has already been graded.";
                        }
                    }

                }
                else
                {
                    ltlGrades.Text = "Please select a student and chose a grade before submitting";
                }

            }
            else
            {
                ltlGrades.Text = "Error! Cannot post grades outside of grade posting period";
            }

        }

        SqlDataReader selectcmd(string strSelect, string connstring)
        {
            SqlConnection conn = new SqlConnection(connstring);

            SqlCommand cmdSelect = new SqlCommand(strSelect, conn);

            SqlDataReader cmdReader;

            conn.Open();
            cmdReader = cmdSelect.ExecuteReader();

            return cmdReader;

        }

        protected void SignOut_Click(object sender, EventArgs e)
        {
            FormsAuthentication.SignOut();
            Response.Redirect("~/Home.aspx");
        }
    }

}