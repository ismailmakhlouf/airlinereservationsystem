﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Banner
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsCallback && !Page.IsPostBack)
            {
                txtAddStart.Text = DateTime.Today.AddDays(0).ToString();
                txtAddEnd.Text = DateTime.Today.AddDays(7).ToString();
                txtDropStart.Text = txtAddStart.Text;
                txtDropEnd.Text = DateTime.Today.AddMonths(1).ToString();
                txtPostStart.Text = DateTime.Today.AddDays(8).ToString();
                txtPostEnd.Text = DateTime.Today.AddMonths(2).ToString();
            }
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ltlRegistration.Text = "";
            bool error = false;
            DateTime AddStart = Convert.ToDateTime(txtAddStart.Text);
            DateTime AddEnd = Convert.ToDateTime(txtAddEnd.Text);
            DateTime DropStart = Convert.ToDateTime(txtDropStart.Text);
            DateTime DropEnd = Convert.ToDateTime(txtDropEnd.Text);
            DateTime PostStart = Convert.ToDateTime(txtPostStart.Text);
            DateTime PostEnd = Convert.ToDateTime(txtPostEnd.Text);
            string Semester = ddlSemester.SelectedValue;
            string Year = ddlYear.SelectedValue;

            if (AddStart > AddEnd)
            {
                ltlRegistration.Text += "Error! End Date cannot precede Start Date for adding courses ";
                error = true;
            }

            if (DropStart < AddStart)
            {
                ltlRegistration.Text += "Error! Drop Start Date cannot precede Add Start Date";
                error = true;
            }

            if (DropStart > DropEnd)
            {
                ltlRegistration.Text += "Error! End Date cannot precede Start Date for dropping courses ";
                error = true;
            }

            if (PostStart > PostEnd)
            {
                ltlRegistration.Text += "Error! End Date cannot precede Start Date for posting grades ";
                error = true;
            }

            if (PostStart < AddStart)
            {
                ltlRegistration.Text += "Error! Cannot post grades before start of courses";
                error = true;
            }


            if (PostStart <= AddEnd)
            {
                ltlRegistration.Text += "Error! Cannot post grades during add period";
                error = true;
            }

            if (error == false)
            {
                string strUpdate = "UPDATE Deadlines "
                                       + "SET AddStart = '" + AddStart.Date + "' "
                                       + ", AddEnd = '" + AddEnd.Date + "' "
                                       + ", DropStart = '" + DropStart.Date + "' "
                                       + ", DropEnd = '" + DropEnd.Date + "' "
                                       + ", PostStart = '" + PostStart.Date + "' "
                                       + ", PostEnd = '" + PostEnd.Date + "' "
                                       + "WHERE (Semester = '" + Semester + "') "
                                       + "AND (Year = " + Year + ")";


                SqlConnection conn2 = new SqlConnection();
                conn2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|UniversityServices.mdf;Integrated Security=True;User Instance=True";

                SqlCommand cmdInsert = new SqlCommand(strUpdate, conn2);

                //SqlDataReader cmdReader;

                conn2.Open();
                try
                {

                    cmdInsert.ExecuteNonQuery();
                    //cmdReader.Read();
                    //string userid = cmdReader.GetValue(0).ToString();
                    conn2.Close();
                    ltlRegistration.Visible = true;
                    ltlRegistration.Text = "Success! Deadlines have now been defined";

                    //lblNoteAdd0.Text = "Success! " + MajorCode + " " + CourseNo + " has been added.";
                    //gvViewSched.UpdateMethod();
                }
                catch (SqlException ex)
                {
                    if (ex.Number == 2627)
                    {
                        ltlRegistration.Text = "Error! Deadlines have not been defined";
                    }
                }
            }

            
        }

        protected void btnUpdateRole_Click(object sender, EventArgs e)
        {
            GridViewRow offer = gvUserNameRoles.SelectedRow;

            if (offer != null)
            {

                string username = offer.Cells[1].Text;
                string rolename = offer.Cells[2].Text;

                Roles.RemoveUserFromRole(username, rolename);
                Roles.AddUserToRole(username, ddlRole.SelectedValue);  
            }
        
        }

        protected void ExecuteSql_Click(object sender, EventArgs e)
        {
            string strsql = txtSql.Text;

            
            SqlConnection conn2 = new SqlConnection();
            conn2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|UniversityServices.mdf;Integrated Security=True;User Instance=True";

            SqlCommand cmdInsert = new SqlCommand(strsql, conn2);

            //SqlDataReader cmdReader;

            conn2.Open();
            try
            {

                cmdInsert.ExecuteNonQuery();
                //cmdReader.Read();
                //string userid = cmdReader.GetValue(0).ToString();
                conn2.Close();
               
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627)
                {
                    ltlError.Text = "Error! Primary Key Violation";
                }
                else
                {
                    ltlError.Text = "Error! Query Unsuccessful";
                }
            }
        }

        protected void SignOut_Click(object sender, EventArgs e)
        {
            FormsAuthentication.SignOut();
            Response.Redirect("~/Home.aspx");
        }
    }
}