﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Banner.Secure.Student
{
    public partial class Student : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            //lblNoteDrop.Text = "";
            //TabContainer1.AutoPostBack = true;
            //TabContainer1.Visible = true;

            //string user = HttpContext.Current.User.Identity.Name;
            //string strSelect = "SELECT StudentId FROM Student WHERE (UserName = '" + user + "')";


            //SqlConnection conn = new SqlConnection();
            //conn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|UniversityServices.mdf;Integrated Security=True;User Instance=True";


            //SqlCommand cmdSelect = new SqlCommand(strSelect, conn);

            //SqlDataReader cmdReader;

            //conn.Open();
            //cmdReader = cmdSelect.ExecuteReader();
            //cmdReader.Read();
            //string userid = cmdReader.GetValue(0).ToString();


            //HttpCookie usercookie = new HttpCookie("UserId");
            //usercookie.Value = userid;
            //usercookie.Expires = DateTime.Now.AddDays(1);
            //Response.Cookies.Add(usercookie);

            //conn.Close();



        }

        //protected void SelectedIndex_OnChanged(object sender, EventArgs e)
        //{

        //    GridViewRow offer = gvAddDrop.SelectedRow;

        //    if (offer != null)
        //    {

        //        string MajorCode = offer.Cells[1].Text;
        //        string CourseNo = offer.Cells[2].Text;
        //        string SectionNo = offer.Cells[3].Text;
        //        string Semester = offer.Cells[4].Text;
        //        string Year = offer.Cells[5].Text;
        //        string UWMR = offer.Cells[6].Text;
        //        string StartTime = offer.Cells[7].Text;
        //        string FacultyName = offer.Cells[8].Text;

        //        //DataSourceSelectArguments clashdsargs = ClashDS.SelectParameters;
        //        //string s = ClashDS.SelectCommand;

        //        ////SqlDataReader returnrow = (SqlDataReader)ClashDS.Select(DataSourceSelectArguments.Empty);


        //        ////DataView dview = (DataView)ClashDS.Select(DataSourceSelectArguments.Empty);
        //        ////if (dview != null)
        //        ////{
        //        ////    //string mjcode = (String)dview.Table.Rows("MajorCode");
        //        ////    DataRow clashrow = dview.Table.Rows[0];

        //        ////    if (clashrow != null)
        //        ////    {
        //        ////        object[] clashrowarray = clashrow.ItemArray;
        //        ////        lblNoteAdd.Text = "Error! " + MajorCode + " " + CourseNo + " clashes with " + clashrowarray[0] + clashrowarray[1];
        //        ////    }
        //        ////}

        //        //SqlConnection conn = new SqlConnection();
        //        //conn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|UniversityServices.mdf;Integrated Security=True;User Instance=True";


        //        //SqlCommand cmdSelect = new SqlCommand(s, conn);

        //        //SqlDataReader cmdReader;

        //        //conn.Open();
        //        //cmdReader = cmdSelect.ExecuteReader();
        //        //cmdReader.Read();

        //        if (gvClash.Rows.Count > 0)
        //        {
        //            GridViewRow clashrow = gvClash.Rows[1] ;

        //        //if (cmdReader.HasRows)
        //        //{

        //        //    //object[] clashrowarray;
        //        //    //cmdReader.GetValues(clashrowarray);
        //        //    string mjcode = cmdReader.GetValue(0).ToString();
        //        //    string crseno = cmdReader.GetValue(1).ToString();
        //        //    //lblNoteAdd.Text = "Error! " + MajorCode + " " + CourseNo + " clashes with " + clashrowarray[0] + clashrowarray[1];
        //        //    lblNoteAdd.Text = "Error! " + MajorCode + " " + CourseNo + " clashes with " + mjcode + " " + crseno;
        //        //}


        //            //object[] clashrowarray;
        //            //cmdReader.GetValues(clashrowarray);
        //            string mjcode = clashrow.Cells[1].Text;
        //            string crseno = clashrow.Cells[2].Text;
        //            //lblNoteAdd.Text = "Error! " + MajorCode + " " + CourseNo + " clashes with " + clashrowarray[0] + clashrowarray[1];
        //            lblNoteAdd.Text = "Error! " + MajorCode + " " + CourseNo + " clashes with " + mjcode + " " + crseno;
        //        }
        //        else
        //        {
        //            string userid = Response.Cookies["UserId"].Value;

        //            //string strInsert = "INSERT INTO [Transcript] ([StudentId], [MajorCode], [CourseNo], [SectionNo], [Semester], [Year], [Grade]) VALUES (@StudentId, @MajorCode, @CourseNo, @SectionNo, @Semester, @Year, @Grade)";
        //            string strInsert = "INSERT INTO Transcript "
        //                               + " VALUES ('" + userid + "', '"
        //                               + MajorCode + "', '"
        //                               + CourseNo + "', '"
        //                               + SectionNo + "', '"
        //                               + Semester + "', '"
        //                               + Year + "', '"
        //                               + "' )";

        //            SqlConnection conn2 = new SqlConnection();
        //            conn2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|UniversityServices.mdf;Integrated Security=True;User Instance=True";

        //            SqlCommand cmdInsert = new SqlCommand(strInsert, conn2);

        //            //SqlDataReader cmdReader;

        //            conn2.Open();
        //            try
        //            {

        //                cmdInsert.ExecuteNonQuery();
        //                //cmdReader.Read();
        //                //string userid = cmdReader.GetValue(0).ToString();
        //                conn2.Close();
        //                lblNoteAdd.Visible = true;
        //                lblNoteAdd.Text = "Success! " + MajorCode + " " + CourseNo + " has been added.";

        //                //lblNoteAdd0.Text = "Success! " + MajorCode + " " + CourseNo + " has been added.";
        //                //gvViewSched.UpdateMethod();
        //            }
        //            catch(SqlException ex)
        //            {
        //                if (ex.Number == 2627)
        //                {
        //                    lblNoteAdd.Text = "This course has already been added.";
        //                }
        //            }

        //        }
        //    }

        //}

        //protected void SelectedIndex_OnChanged2(object sender, EventArgs e)
        //{

        //    string strSelect = "SELECT Semester, Year, AddStart, AddEnd, DropStart, DropEnd, PostStart, PostEnd "
        //                           + "FROM Deadlines "
        //                           + "WHERE (Semester = '" + ddlSemester3.Text + "') "
        //                           + "AND (Year = " + ddlYear3.Text + ") ";

        //    SqlDataReader cmdReaderdates;

        //    string connstring = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|UniversityServices.mdf;Integrated Security=True;User Instance=True";
        //    cmdReaderdates = selectcmd(strSelect, connstring);
        //    cmdReaderdates.Read();

        //    DateTime DropStart = (DateTime)cmdReaderdates.GetValue(4);
        //    DateTime DropEnd = (DateTime)cmdReaderdates.GetValue(5);
        //    DateTime now = DateTime.Now;

        //    if ((now >= DropStart) && (now <= DropEnd))
        //    {
        //        GridViewRow offer = gvDrop.SelectedRow;

        //        if (offer != null)
        //        {

        //            string MajorCode = offer.Cells[1].Text;
        //            string CourseNo = offer.Cells[2].Text;
        //            string SectionNo = offer.Cells[3].Text;
        //            string Semester = offer.Cells[4].Text;
        //            string Year = offer.Cells[5].Text;
        //            string UWMR = offer.Cells[6].Text;
        //            string StartTime = offer.Cells[7].Text;
        //            string FacultyName = offer.Cells[8].Text;


        //            string userid = Response.Cookies["UserId"].Value;


        //            string strDelete = "DELETE FROM Transcript "
        //                                + " WHERE (StudentId = '" + userid + "') AND "
        //                                + "(MajorCode = '" + MajorCode + "') AND "
        //                                + "(CourseNo = '" + CourseNo + "') AND "
        //                                + "(SectionNo = " + SectionNo + ") AND "
        //                                + "(Semester = '" + Semester + "') AND "
        //                                + "(Year = " + Year + ")";

        //            SqlConnection conn3 = new SqlConnection();
        //            conn3.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|UniversityServices.mdf;Integrated Security=True;User Instance=True";

        //            SqlCommand cmdDelete = new SqlCommand(strDelete, conn3);


        //            conn3.Open();
        //            cmdDelete.ExecuteNonQuery();
        //            //cmdReader.Read();
        //            //string userid = cmdReader.GetValue(0).ToString();
        //            conn3.Close();
        //            lblNoteDrop.Text = "Success! " + MajorCode + " " + CourseNo + " has been dropped.";
        //        }
        //    }
        //    else
        //    {
        //        lblNoteDrop.Text = "Error! Cannot drop course outside of drop period";
        //    }

        //}

        //protected void SelectedIndex_OnChanged3(object sender, EventArgs e)
        //{
        //    lblNoteDrop0.Text = "";
        //    bool clash = false;
        //    bool prereqmissing = false;
        //    bool duplicate = false;

        //    string strSelect = "SELECT Semester, Year, AddStart, AddEnd, DropStart, DropEnd, PostStart, PostEnd "
        //                           + "FROM Deadlines "
        //                           + "WHERE (Semester = '" + ddlSemester3.Text + "') "
        //                           + "AND (Year = " + ddlYear3.Text + ") ";

        //    SqlDataReader cmdReaderdates;

        //    string connstring = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|UniversityServices.mdf;Integrated Security=True;User Instance=True";
        //    cmdReaderdates = selectcmd(strSelect, connstring);
        //    cmdReaderdates.Read();

        //    DateTime AddStart = (DateTime)cmdReaderdates.GetValue(2);
        //    DateTime AddEnd = (DateTime)cmdReaderdates.GetValue(3);
        //    DateTime now = DateTime.Now;

        //    if ((now >= AddStart) && (now <= AddEnd))
        //    {

        //        GridViewRow offer = gvFlights0.SelectedRow;
        //        string userid = Response.Cookies["UserId"].Value;

        //        if (offer != null)
        //        {

        //            string MajorCode = offer.Cells[1].Text;
        //            string CourseNo = offer.Cells[2].Text;
        //            string SectionNo = offer.Cells[3].Text;
        //            string Semester = offer.Cells[4].Text;
        //            string Year = offer.Cells[5].Text;
        //            string UWMR = offer.Cells[6].Text;
        //            string StartTime = offer.Cells[7].Text;
        //            string FacultyName = offer.Cells[8].Text;

        //            // Checking for prerequisites

        //            strSelect = "SELECT DISTINCT PreMajCode, PreCourseNo "
        //                                + "FROM Course "
        //                                + "WHERE (MajorCode = '" + MajorCode + "') "
        //                                + "AND (CourseNo = '" + CourseNo + "') ";

        //            SqlDataReader cmdReader;

        //            cmdReader = selectcmd(strSelect, connstring);
        //            cmdReader.Read();

        //            string premjcode = cmdReader.GetValue(0).ToString();
        //            string precrseno = cmdReader.GetValue(1).ToString();

        //            if (premjcode != "")
        //            {

        //                string strSelect2 = "SELECT DISTINCT [PreMajCode], [PreCourseNo] "
        //                                + "FROM [Transcript-Prerequisite] "
        //                                + "WHERE ([StudentId] = '" + userid + "') "
        //                                + "AND ([MajorCode] = '" + MajorCode + "') "
        //                                + "AND ([CourseNo] = '" + CourseNo + "') "
        //                                + "AND ([Year] < " + Year + ")";

        //                SqlDataReader cmdReader2;
        //                cmdReader2 = selectcmd(strSelect2, connstring);
        //                cmdReader2.Read();

        //                if (cmdReader2.HasRows == false)
        //                {
        //                    //string studentpremjcode = cmdReader2.GetValue(0).ToString();
        //                    //string studentprecrseno = cmdReader2.GetValue(1).ToString();

        //                    //if ((premjcode + precrseno) != (studentpremjcode + studentprecrseno))
        //                    //{
        //                    lblNoteDrop0.Text = "Error! Missing Prerequisite: " + premjcode + " " + precrseno + "            \n\r";
        //                    prereqmissing = true;
        //                    //}
        //                }

        //            }

        //            // Checking for clashes

        //            string strSelect3 = "SELECT DISTINCT MajorCode, CourseNo "
        //                                + "FROM [Student-Offerings] "
        //                                + "WHERE (StudentId = '" + userid + "') "
        //                                + "AND (MajorCode <> '" + MajorCode + "') "
        //                                + "AND (CourseNo <> '" + CourseNo + "') "
        //                                + "AND (UWMR = '" + UWMR + "') "
        //                                + "AND (StartTime = '" + StartTime + "') "
        //                                + "AND (Semester = '" + Semester + "') "
        //                                + "AND (Year = " + Year + ")";


        //            SqlDataReader cmdReader3;
        //            cmdReader3 = selectcmd(strSelect3, connstring);
        //            cmdReader3.Read();


        //            if (cmdReader3.HasRows)
        //            {
        //                string mjcode = cmdReader3.GetValue(0).ToString();
        //                string crseno = cmdReader3.GetValue(1).ToString();
        //                lblNoteDrop0.Text += "Error! " + MajorCode + " " + CourseNo + " clashes with " + mjcode + " " + crseno + "            ";
        //                clash = true;
        //            }


        //            // Checking for duplicate registration

        //            string strSelect4 = "SELECT StudentId, MajorCode, CourseNo, SectionNo, Semester, Year, UWMR, StartTime, FacultyName "
        //                                + "FROM [Student-Offerings] "
        //                                + "WHERE (StudentId = '" + userid + "') "
        //                                + "AND (MajorCode = '" + MajorCode + "') "
        //                                + "AND (CourseNo = '" + CourseNo + "') "
        //                                + "AND (SectionNo <> " + SectionNo + ") "
        //                                + "AND (Semester = '" + Semester + "') "
        //                                + "AND (Year = " + Year + ")";


        //            SqlDataReader cmdReader4;
        //            cmdReader4 = selectcmd(strSelect4, connstring);
        //            cmdReader4.Read();


        //            if (cmdReader4.HasRows)
        //            {
        //                string secno = cmdReader4.GetValue(3).ToString();

        //                lblNoteDrop0.Text += "Error! You are already registered in section " + secno + " of " + MajorCode + " " + CourseNo;
        //                duplicate = true;
        //            }
        //            if (clash == false && prereqmissing == false && duplicate == false)
        //            {

        //                //string strInsert = "INSERT INTO [Transcript] ([StudentId], [MajorCode], [CourseNo], [SectionNo], [Semester], [Year], [Grade]) VALUES (@StudentId, @MajorCode, @CourseNo, @SectionNo, @Semester, @Year, @Grade)";
        //                string strInsert = "INSERT INTO Transcript "
        //                                   + " VALUES ('" + userid + "', '"
        //                                   + MajorCode + "', '"
        //                                   + CourseNo + "', '"
        //                                   + SectionNo + "', '"
        //                                   + Semester + "', '"
        //                                   + Year + "', '"
        //                                   + "' )";

        //                SqlConnection conn2 = new SqlConnection();
        //                conn2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|UniversityServices.mdf;Integrated Security=True;User Instance=True";

        //                SqlCommand cmdInsert = new SqlCommand(strInsert, conn2);

        //                //SqlDataReader cmdReader;

        //                conn2.Open();
        //                try
        //                {

        //                    cmdInsert.ExecuteNonQuery();
        //                    //cmdReader.Read();
        //                    //string userid = cmdReader.GetValue(0).ToString();
        //                    conn2.Close();
        //                    lblNoteDrop0.Visible = true;
        //                    lblNoteDrop0.Text = "Success! " + MajorCode + " " + CourseNo + " has been added.";

        //                    //lblNoteAdd0.Text = "Success! " + MajorCode + " " + CourseNo + " has been added.";
        //                    //gvViewSched.UpdateMethod();
        //                }
        //                catch (SqlException ex)
        //                {
        //                    if (ex.Number == 2627)
        //                    {
        //                        lblNoteDrop0.Text = "This course has already been added";
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    else
        //    {
        //        lblNoteDrop0.Text = "Error! Cannot add course outside of add period";
        //    }
        //}
        //SqlDataReader selectcmd(string strSelect, string connstring)
        //{
        //    SqlConnection conn = new SqlConnection(connstring);

        //    SqlCommand cmdSelect = new SqlCommand(strSelect, conn);

        //    SqlDataReader cmdReader;

        //    conn.Open();
        //    cmdReader = cmdSelect.ExecuteReader();

        //    return cmdReader;

        //}

        protected void SignOut_Click(object sender, EventArgs e)
        {
            FormsAuthentication.SignOut();
            Response.Redirect("~/Home.aspx");
        }


    }
}

